import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import FooterComponents from './Components/FooterComponents';
import HeaderComponents from './Components/HeaderComponents';

function App() {
  return (
    <>
      <BrowserRouter>
        <HeaderComponents />
        <Routes>
          {/* Home Route - Lists all patients */}
          <Route path="/" element={<ListPatientComponent />} />

          {/* Patients List Page */}
          <Route path="/patient" element={<ListPatientComponent />} />

          {/* Add New Employee Page */}
          <Route path="/add-patient" element={<PatientComponents />} />

          {/* Edit Existing Employee Page */}
          <Route path="/edit-patient/:id" element={<PatientComponents />} />
          <Route path='/view-patient/:id' element={<ViewPatientComponent />} />
        </Routes>
        <FooterComponents />
      </BrowserRouter>
    </>
  );
}

export default App;