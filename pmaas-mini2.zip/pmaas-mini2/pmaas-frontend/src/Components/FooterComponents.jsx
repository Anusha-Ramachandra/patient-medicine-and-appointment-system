import React from 'react'

const FooterComponents = () => {
  return (
    <div>
        <footer className='footer'> 
            <span>All rights reserved 2025 by pmaas</span>
        </footer>

    </div>
  )
}

export default FooterComponents
