import React, { useEffect, useState } from 'react';
import { listPatient, getPatient, deletePatient } from '../services/patientService';
import { useNavigate } from 'react-router-dom';

const ListPatientComponent = () => {
    const [patients, setPatients] = useState([]);
    const navigator = useNavigate();

    useEffect(() => {
        fetchPatients();
    }, []);

    // Fetch Patients
    const fetchPatients = () => {
        listPatients()
            .then((response) => {
                setPatients(response.data);
            })
            .catch((error) => {
                console.error('Error fetching patients:', error);
            });
    };

    // Add Patient
    const addNewPatient = () => {
        navigator('/add-Patient');
    };

    // Update Patient
    const updatePatient = (id) => {
        navigator(`/edit-Patient/${id}`);
    };

    // View Patient
    const viewPatient = (id) => {
        navigator(`/view-Patient/${id}`);
    };
    

    // Delete Patient
    const deletePatientById = (id) => {
        if (window.confirm('Are you sure you want to delete this Patient?')) {
            deletePatient(id)
                .then(() => {
                    alert('Patient deleted successfully');
                    fetchPatient(); // Refresh the list after deleting
                })
                .catch((error) => {
                    console.error('Error deleting Patient:', error);
                });
        }
    };

    return (
        <div className='container'>
            <h2>List of Patients</h2>
            <button className='btn btn-primary mb-2' onClick={addNewPatient}>Add Patient</button>
            <table className='table table-striped table-bordered'>
                <thead>
                    <tr>
                        <th>Patient ID</th>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Medical History</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {Patients.map((Patient) => (
                        <tr key={Patient.id}>
                            <td>{Patient.id}</td>
                            <td>{Patient.name}</td>
                            <td>{Patient.contact}</td>
                            <td>{Patient.medicalHistory}</td>
                            <td>
                                <button className='btn btn-info mx-1' onClick={() => updatePatient(patient.id)}>Update</button>
                                <button className='btn btn-danger mx-1' onClick={() => deletePatientById(patient.id)}>Delete</button>
                                <button className='btn btn-secondary mx-1' onClick={() => viewPatient(patient.id)}>View</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ListPatientComponent;
