import React, { useEffect, useState } from 'react';
import { createPatient, getPatient, updatePatient } from '../services/patientService';
import { useNavigate, useParams } from 'react-router-dom';

const PatientComponents = () => {
    const [name, setName] = useState('');
    const [contact, setContact] = useState('');
    const [medicalHistory, setMedicalHistory] = useState('');
    const { id } = useParams();
    const navigator = useNavigate();

    const [errors, setErrors] = useState({
        Name: '',
        contact: '',
        medicalHistory: '',
        id:''
    });

    useEffect(() => {
        if (id) {
            getPatient(id)
                .then((response) => {
                    setName(response.data.name);
                    setContact(response.data.contact);
                    setMedicalHistory(response.data.medicalHistory);
                })
                .catch((error) => {
                    console.error(error);
                });
        }
    }, [id]);

    function handleName(e) {
        setName(e.target.value);
    }

    function handleContact(e) {
        setContact(e.target.value);
    }

    function handleMedicalHistory(e) {
        setMedicalHistory(e.target.value);
    }

    function validateForm() {
        let valid = true;
        const errorsCopy = { name: '', contact: '', medicalHistory: '' };

        if (!name.trim()) {
            errorsCopy.name = 'name is required';
            valid = false;
        }

        if (!contact.trim()) {
            errorsCopy.contact = 'contact is required';
            valid = false;
        }

        if (!medicalHistory.trim()) {
            errorsCopy.medicalHistory = 'medicalHistory is required';
            valid = false;
        }

        setErrors(errorsCopy);
        return valid;
    }

    function saveOrUpdatePatient(e) {
        e.preventDefault();
        if (validateForm()) {
            const patient = { name, contact, medicalHistory };

            if (id) {
                updatePatient(id, patient)
                    .then(() => navigator('/patients'))
                    .catch((error) => console.error(error));
            } else {
                createpatient(patient)
                    .then(() => navigator('/patients'))
                    .catch((error) => console.error(error));
            }
        }
    }

    function pageTitle() {
        return <h2 className='text-center'>{id ? 'Update Patient' : 'Add Patient'}</h2>;
    }

    return (
        <div className='container'>
            <div className='row'>
                <div className='card col-md-6 offset-md-3'>
                    {pageTitle()}
                    <div className='card-body'>
                        <form>
                            <div className='form-group mb-2'>
                                <label className='form-label'>Name:</label>
                                <input
                                    type='text'
                                    placeholder='Enter Patient Name'
                                    name='name'
                                    value={name}
                                    className={`form-control ${errors.name ? 'is-invalid' : ''}`}
                                    onChange={handleName}
                                />
                                {errors.name && <div className='invalid-feedback'>{errors.name}</div>}
                            </div>

                            <div className='form-group mb-2'>
                                <label className='form-label'>Contact:</label>
                                <input
                                    type='text'
                                    placeholder='Enter Patient Contact'
                                    name='contact'
                                    value={contact}
                                    className={`form-control ${errors.contact ? 'is-invalid' : ''}`}
                                    onChange={handleContact}
                                />
                                {errors.contact && <div className='invalid-feedback'>{errors.contact}</div>}
                            </div>

                            <div className='form-group mb-2'>
                                <label className='form-label'>MedicalHistory:</label>
                                <input
                                    type='text'
                                    placeholder='Enter Patient Medical History'
                                    name='medicalHistory'
                                    value={medicalHistory}
                                    className={`form-control ${errors.medicalHistory ? 'is-invalid' : ''}`}
                                    onChange={handleMedicalHistory}
                                />
                                {errors.medicalHistory && <div className='invalid-feedback'>{errors.medicalHistory}</div>}
                            </div>

                            <button className='btn btn-success' onClick={saveOrUpdatePatient}>
                                Submit
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PatientComponents;
