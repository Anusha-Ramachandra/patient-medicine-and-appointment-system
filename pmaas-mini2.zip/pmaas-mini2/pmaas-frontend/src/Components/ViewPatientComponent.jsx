import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getEmployee } from '../services/PatientServices';

const ViewPatientComponent = () => {
    const { id } = useParams();
    const [employee, setPatient] = useState(null);

    useEffect(() => {
        getPatient(id)
            .then((response) => {
                setPatient(response.data);
            })
            .catch((error) => {
                console.error('Error fetching patient details:', error);
            });
    }, [id]);

    return (
        <div className="container">
            <h2 className="text-center">Patient Details</h2>
            {patient ? (
                <div className="card p-4">
                    <p><strong>ID:</strong> {patient.id}</p>
                    <p><strong>Name:</strong> {patient.name}</p>
                    <p><strong>Contact:</strong> {patient.contact}</p>
                    <p><strong>Medical History:</strong> {patient.medicalHistory}</p>
                </div>
            ) : (
                <p>Loading patient details...</p>
            )}
        </div>
    );
};

export default ViewPatientComponent;
