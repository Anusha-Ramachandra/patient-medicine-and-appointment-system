const apiBaseUrl = "http://localhost:8080/patients";

// Load all patients when page loads
document.addEventListener("DOMContentLoaded", loadPatients);

// Function to load patients
function loadPatients() {
    fetch(apiBaseUrl + "/all")
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById("patientTableBody");
            tableBody.innerHTML = "";
            data.forEach(patient => {
                tableBody.innerHTML += `
                    <tr>
                        <td>${patient.id}</td>
                        <td>${patient.name}</td>
                        <td>${patient.contact}</td>
                        <td>${patient.medicalHistory || 'N/A'}</td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="editPatient(${patient.id})">Edit</button>
                            <button class="btn btn-danger btn-sm" onclick="deletePatient(${patient.id})">Delete</button>
                        </td>
                    </tr>`;
            });
        });
}

// Handle form submission for adding patients
document.getElementById("patientForm").addEventListener("submit", function(event) {
    event.preventDefault();
    const patientData = {
        name: document.getElementById("name").value,
        contact: document.getElementById("contact").value,
        medicalHistory: document.getElementById("medicalHistory").value
    };

    fetch(apiBaseUrl + "/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patientData)
    })
    .then(response => response.json())
    .then(() => {
        loadPatients(); // Refresh table
        document.getElementById("patientForm").reset(); // Clear form
    });
});

// Delete a patient
function deletePatient(id) {
    if (confirm("Are you sure you want to delete this patient?")) {
        fetch(apiBaseUrl + `/delete/${id}`, { method: "DELETE" })
            .then(() => loadPatients());
    }
}

// Edit patient (Redirect to update form)
function editPatient(id) {
    window.location.href = `update-patient.html?id=${id}`;
}

