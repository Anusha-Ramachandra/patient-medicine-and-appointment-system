const backendUrl = "http://localhost:8080";
const token = localStorage.getItem("token");

if (!token) {
    alert("Please log in first.");
    window.location.href = "index.html";
}

// Fetch available slots
async function getAvailableSlots() {
    try {
        const response = await fetch(`${backendUrl}/api/appointments/available`, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        if (response.ok) {
            const slots = await response.json();
            const list = document.getElementById("slotsList");

            if (slots.length === 0) {
                list.innerHTML = "<li>No available slots.</li>";
            } else {
                slots.forEach(slot => {
                    const li = document.createElement("li");
                    li.textContent = `Dr. ${slot.doctorName} - ${slot.date}`;
                    const button = document.createElement("button");
                    button.textContent = "Book";
                    button.onclick = () => bookAppointment(slot.id);
                    li.appendChild(button);
                    list.appendChild(li);
                });
            }
        } else {
            alert("Failed to load available slots.");
        }
    } catch (error) {
        console.error("Error:", error);
    }
}

// Book an appointment
async function bookAppointment(slotId) {
    try {
        const response = await fetch(`${backendUrl}/api/appointments/book`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify({ slotId })
        });

        if (response.ok) {
            alert("Appointment booked successfully!");
            window.location.href = "dashboard.html";
        } else {
            alert("Failed to book appointment.");
        }
    } catch (error) {
        console.error("Error:", error);
    }
}

// Load slots on page load
getAvailableSlots();
