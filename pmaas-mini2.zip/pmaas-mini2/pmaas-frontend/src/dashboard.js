const backendUrl = "http://localhost:8080";
const token = localStorage.getItem("token");

if (!token) {
    alert("Please log in first.");
    window.location.href = "index.html";
}

// Fetch user data
async function getUserData() {
    try {
        const response = await fetch(`${backendUrl}/api/user/profile`, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        if (response.ok) {
            const user = await response.json();
            document.getElementById("username").textContent = user.name;
        } else {
            alert("Failed to load user data.");
        }
    } catch (error) {
        console.error("Error:", error);
    }
}

// Fetch appointments
async function getAppointments() {
    try {
        const response = await fetch(`${backendUrl}/api/appointments`, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        if (response.ok) {
            const appointments = await response.json();
            const list = document.getElementById("appointmentsList");

            if (appointments.length === 0) {
                list.innerHTML = "<li>No upcoming appointments.</li>";
            } else {
                appointments.forEach(app => {
                    const li = document.createElement("li");
                    li.textContent = `Dr. ${app.doctorName} on ${app.date}`;
                    list.appendChild(li);
                });
            }
        } else {
            alert("Failed to load appointments.");
        }
    } catch (error) {
        console.error("Error:", error);
    }
}

// Logout
document.getElementById("logoutBtn").addEventListener("click", function() {
    localStorage.removeItem("token");
    window.location.href = "index.html";
});

// Call functions on page load
getUserData();
getAppointments();
