const backendUrl = "http://localhost:8080"; // Change if necessary

// User Registration
document.getElementById("registerForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    
    const userData = {
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        password: document.getElementById("password").value
    };

    try {
        const response = await fetch(`${backendUrl}/patients`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(userData)
        });

        if (response.ok) {
            alert("Registration successful! Please login.");
        } else {
            alert("Registration failed.");
        }
    } catch (error) {
        console.error("Error:", error);
    }
});

// User Login
document.getElementById("loginForm").addEventListener("submit", async function(e) {
    e.preventDefault();

    const loginData = {
        email: document.getElementById("loginEmail").value,
        password: document.getElementById("loginPassword").value
    };

    try {
        const response = await fetch(`${backendUrl}/api/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(loginData)
        });

        const data = await response.json();
        
        if (response.ok) {
            localStorage.setItem("token", data.token);
            alert("Login successful!");
            window.location.href = "dashboard.html"; // Redirect to dashboard
        } else {
            alert("Login failed.");
        }
    } catch (error) {
        console.error("Error:", error);
    }
});
