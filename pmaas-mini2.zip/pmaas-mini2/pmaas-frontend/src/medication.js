const backendUrl = "http://localhost:8080";
const token = localStorage.getItem("token");

if (!token) {
    alert("Please log in first.");
    window.location.href = "index.html";
}

// Fetch medications
async function getMedications() {
    try {
        const response = await fetch(`${backendUrl}/api/medications`, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        if (response.ok) {
            const medications = await response.json();
            const list = document.getElementById("medicationsList");

            if (medications.length === 0) {
                list.innerHTML = "<li>No medications found.</li>";
            } else {
                medications.forEach(med => {
                    const li = document.createElement("li");
                    li.textContent = `${med.name} - ${med.dosage}`;
                    list.appendChild(li);
                });
            }
        } else {
            alert("Failed to load medications.");
        }
    } catch (error) {
        console.error("Error:", error);
    }
}

// Load medications on page load
getMedications();
