const apiBaseUrl = "/api/patients"; // ✅ Uses Vite Proxy


console.log("patient.js is loaded!");

// ✅ Load all patients
async function loadPatients() {
    try {
        const response = await fetch(apiBaseUrl); // FIXED: Removed "/all"
        if (!response.ok) throw new Error("Error loading patients");

        const data = await response.json();
        console.log("Fetched Patients:", data); // Debugging step

        const patientList = document.getElementById("patientTableBody");
        patientList.innerHTML = ""; // Clear previous content

        data.forEach(patient => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${patient.id}</td>
                <td>${patient.name}</td>
                <td>${patient.contact}</td>
                <td>${patient.medicalHistory}</td>
                <td>
                    <button class="btn btn-warning btn-sm" onclick="editPatient(${patient.id})">Edit</button>
                    <button class="btn btn-danger btn-sm" onclick="deletePatient(${patient.id})">Delete</button>
                </td>`;
            patientList.appendChild(row);
        });

    } catch (error) {
        console.error("Error loading patients:", error);
    }
}

// ✅ Add a new patient
document.getElementById("add-patient-form")?.addEventListener("submit", async function(event) {
    event.preventDefault();

    console.log("Add Patient Form Submitted!");

    const patientData = {
        name: document.getElementById("name").value,
        contact: document.getElementById("contact").value,
        medicalHistory: document.getElementById("medicalHistory").value
    };

    console.log("Patient Data:", patientData);

    try {
        const response = await fetch(apiBaseUrl, { // FIXED: Removed "/register"
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(patientData)
        });

        console.log("Response Status:", response.status);

        if (!response.ok) throw new Error("Error adding patient");

        alert("Patient added successfully!");
        loadPatients(); // Reload patient list
        document.getElementById("add-patient-form").reset();

    } catch (error) {
        console.error("Error adding patient:", error);
        alert("Error adding patient.");
    }
});

// ✅ Delete a patient
async function deletePatient(id) {
    if (!confirm("Are you sure you want to delete this patient?")) return;

    try {
        const response = await fetch(apiBaseUrl + `/${id}`, { // FIXED: Removed "/delete"
            method: "DELETE"
        });

        if (!response.ok) throw new Error("Error deleting patient");

        alert("Patient deleted successfully!");
        loadPatients(); // Refresh list

    } catch (error) {
        console.error("Error deleting patient:", error);
        alert("Error deleting patient.");
    }
}
