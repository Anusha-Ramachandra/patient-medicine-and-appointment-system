const API_URL = "http://localhost:8080/api/patients"; // Change this if needed

// Function to add a patient
export const addPatient = async (patientData) => {
  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(patientData),
    });

    if (!response.ok) {
      throw new Error("Failed to add patient");
    }

    return await response.json(); // Return the created patient object
  } catch (error) {
    console.error("Error adding patient:", error);
    throw error;
  }
};

// Function to fetch all patients
export const getPatients = async () => {
  try {
    const response = await fetch(API_URL);
    if (!response.ok) {
      throw new Error("Failed to fetch patients");
    }
    return await response.json();
  } catch (error) {
    console.error("Error fetching patients:", error);
    throw error;
  }
};
